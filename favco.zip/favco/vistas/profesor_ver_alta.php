<?php
    class ProfesorVerAlta{
        private $config;

        public function __construct($config) {
            $this->config=$config;
        }

        public function mostrar($mensaje = null){
            require_once($this->config['dir_html'].'profesor_ver_alta.html');
            die();
        }

    }   