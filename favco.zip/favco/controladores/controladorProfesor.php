<?php

    /** Controlador
     *      Responsabilidad:
     *      - Recibir los datos de ususario
     *      - Aplicar regla de negocio
     *      - Navegación 
     *      
     */

    class controladorProfesor{
        private $config;

        public function __construct($config) {
            $this->config = $config;
        }

        public function verAlta($mensaje = null){
            require_once($this->config['dir_vistas'].'profesor_ver_alta.php');
            $vista = new ProfesorVerAlta($this->config);
            $vista->mostrar($mensaje);
        }
    }