<?php
try{
    $metodo = strtoupper($_SERVER['REQUEST_METHOD']);
    // throw new Exception("TEst de excepcion");
    switch($metodo){
            case 'GET':
                    listar();
                    break;
            case 'POST':
                    insertar();
                    break;
            case 'DELETE':
                    eliminar();
                    break;      
            case 'PUT':
                    actualizar();
                    break;         
            default:
                    http_response_code(501);
                    echo 'No Implementado (Error 1)';
                    die();             
            
    }

}catch(Throwable $Exception){
    http_response_code(400);
    echo "Error en el servidor";
}

die();


function  actualizar(){
 
    $datos = json_decode(file_get_contents('php://input'), true);
    // TODO: refactorizar, hacer un método para comprobar y obtener parámetros de query
    // getParametrosQuery($nombre) : string

    
    if (!array_key_exists('id', $_GET) || trim($_GET['id']) == ""){
        http_response_code(400);
        echo "Falta el parámetro id";
        die();
    }    
    $id = $_GET['id'];

    if (!array_key_exists('titulo', $datos) || trim($datos['titulo']) == ""){
        http_response_code(400);
        echo "Falta el parámetro título";
        die();
    }

    if (!array_key_exists('bajas', $datos) || trim($datos['bajas']) == ""){
        http_response_code(400);
        echo "Falta el parámetro título";
        die();
    }

    if (!array_key_exists('bajas', $datos) || !is_numeric($datos['bajas'] || $datos['bajas'] < 0)){
            http_response_code(400);
            echo "Falta el parámetro título";
            die();
    }
    

    //Llamamos al modelo con los datos y nos devuelve el id de recurso insertado
    $respuesta = ["url" => "http://localhost/armagedon/?id=$id"];   //HATEOAS 
    http_response_code(200);
    echo json_encode($respuesta, true);


}

function eliminar(){
    if (!array_key_exists('id', $_GET) || trim($_GET['id']) == ""){
        http_response_code(400);
        echo "Falta el parámetro id";
        die();
    }

    $id = $_GET['id'];
    // modelo
    
    //Si no existe el elemento
    $existe_recurso = false;
    if(!$existe_recurso){
        http_response_code(400);
        echo "No existe un armagedón con ese id ($id)";
        die();
    }
    // Borrado
    http_response_code(204);
    die();
}

function listar(){

        //Llamo al modelo y obtengo la lista de armagedones:
        $respuesta = [
                ['id' => 1, 'bajas' => 5000000000, 'titulo' => 'Guerra nuclear total'],
                ['id' => 2, 'bajas' => 300000000, 'titulo' => 'Pandemia de gripe aviar'],
                ['id' => 3, 'bajas' => 7000000000,'titulo' => 'Invasión alienígena']
        ];

        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($respuesta);
}

function insertar(){
        $datos = json_decode(file_get_contents('php://input'), true);

        //Comprobar los parámetros
        //Viene título
        if (!array_key_exists('titulo', $datos) || trim($datos['titulo']) == ""){
                http_response_code(400);
                echo "Falta el parámetro título";
                die();
        }
        if (!array_key_exists('bajas', $datos) || !is_numeric($datos['bajas'] || $datos['bajas'] < 0)){
                http_response_code(400);
                echo "Falta el parámetro título";
                die();
        }


        //Llamamos al modelo con los datos y nos devuelve el id de recurso insertado
        $id_insertado = 42;
        $respuesta = ["url" => "http://localhost/armagedon/?id=$id_insertado"]; //HATEOAS
        http_response_code(201);
        echo json_encode($respuesta, true);
}