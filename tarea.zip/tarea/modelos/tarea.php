<?php 

    require_once('./servicios/bd.php');
    class Tarea{
        private $id;
        private $titulo;
        private $prioridad;
        private $fecha;
        private $base_datos;

        public function __construct($titulo, $prioridad, $fecha) {
            $this->id = null;
            $this->titulo = $titulo;
            $this->prioridad = $prioridad;
            $this->fecha = $fecha;
            $this->base_datos = new BD;
        }

        public function __toString(){
            return $this->id . " " . $this->titulo . " " . $this->prioridad . " " . $this->fecha;
        }

        public function getId(){
            return $this->id; 
        }
        
        // Crea la query para guardar una nueva tarea
        public function guardar(){
            try{
                $sql = "INSERT INTO tarea (titulo, prioridad, fecha) VALUES (?,?,?)";
                $parametros = [$this->titulo, $this->prioridad, $this->fecha];

                $this->base_datos->insertar($sql, $parametros);
            
            }catch(Throwable $e){
                header("HTTP/2 500 Internal Server Error");
                echo "Error: insertar base datos modelo/tarea.php en guardar(). Error: ".$e. "<br>";
            }
        } 

        // Devuelve todas las tareas en la tabla tarea
        public static function listar(){
            try{
                $sql = "SELECT tarea.id, tarea.titulo, tarea.prioridad, tarea.fecha
                        FROM tarea
                        ORDER BY tarea.titulo asc";
                $bd = new bd;
                $tuplas = $bd->buscar($sql, null);

                $tareas = [];
                foreach($tuplas as $tupla){
                    $tarea = new Tarea( $tupla['titulo'], $tupla['prioridad'], $tupla['fecha']);
                    $tarea->id = $tupla['id'];
                    array_push($tareas, $tarea);
                }

                return $tareas;


            }catch(Throwable $e){
                header("HTTP/2 500 Internal Server Error");
                echo "Error: Listar en base datos modelo/tarea.php en listar(). Error: ".$e. "<br>";
            }
        }

        public static function borrar($id){
            try{
                $sql = "DELETE FROM tarea
                        WHERE tarea.id = $id";
                $bd = new bd;  
                $bd -> borrar($sql, null);
            }catch(Throwable $e){
                header("HTTP/2 500 Internal Server Error");
                echo "Error: Borrar en base datos modelo/tarea.php en borrar. Error: ".$e. "<br>";
            }
        }
    }