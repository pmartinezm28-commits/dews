<?php

    require("../modelos/victimas.php");   
   
    if(!empty($_POST)){
        
        // Traemos el dato a buscar
        $buscador = $_POST["buscador"];

        $mensaje = "";
        $coincidencias = array();
         
        // Buscamos si hay coincidencias de víctimas    
        for($i = 0; $i < count($victimas); $i++){
            for($j = 0; $j < count($victimas[$i]); $j++){
                if($victimas[$i][$j] == $buscador){
                   $mensaje = "Encuentra coincidencia/s";   
                   array_push($coincidencias, ($victimas[$i]));
                }            
            }       
        }
        if(count($coincidencias) == 0){
            $mensaje = "No hay coincidencias";
        }

        include("../vista/buscador_victimas.php");

    }
    







     