<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nivel de Riesgo</title>
</head>
    <?php
        if(isset($_POST["victima"])){
            $victima = $_POST["victima"];
            $agresor = $_POST["agresor"];
        }
    ?>
<body>
        <h1>Nivel de Riesgo</h1>
        <p><?php echo "La victima ".$victima ;?> </p>
        <p><?php echo " Se encuentra en un nivel de riesgo: ". $cont_nivel_riesgo ?>   </p>
        <p><?php echo " Frente a su agresor ".$agresor ?>   </p>
        <br/><br/>

</body>
</html>