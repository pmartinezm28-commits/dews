<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="autor" content="Pablo Martínez Masero">
    
    <title>Buscador</title>

    <!--CAMBIAR NOMBRE A INDEX-->
</head>
<body>
    <h1>Página principal</h1>
    <form action="../controlador/contr_busc_victimas.php" method="post">
        <div>
            <label for="buscador">Buscador de victimas: </label> <br>
            <input type="text" id="buscador" name="buscador" class="buscador" placeholder="Buscar" required>
            <input type="submit" class="submit" value="🔎">
        </div>
    </form>
    <br/><br/><br/><br/><br/><br/>

    <!--Muestra todas las coincidencias del buscador-->
    <form action="../vista/form_incidente.php" method="post">
        <div>
            <label for="buscador">Víctimas Registradas:</label>
             <br/><br/>
                <input type="text" size="30" id="coincidencia" name="coincidencia" disabled="true" placeholder = "" 
                value = "<?php if(isset($mensaje)){ 
                        echo $mensaje;
                    }?>"
                >
                <br/><br/>
                <!-- Recorremos el array de coincidencias y las mostramos  -->
                <?php if(isset($coincidencias))
                if(isset($coincidencias))
                foreach ($coincidencias as $i => $victima): ?>
                    <input type="radio" name="victima_agredida" id ="victima_agredida" 
                    value='<?php echo"$victima[0] $victima[1] $victima[2] $victima[3] $victima[4] $victima[5] $victima[6] $victima[7]"; ?>' required>
                    <!-- El value manda como string -->
                    
                    <label> 
                         <?php echo"$victima[0] $victima[1]  $victima[2] Edad: $victima[3] | Dirección: $victima[5] $victima[6] | Documento:$victima[7] <br/>"; ?>
                    </label>
                <?php endforeach?>    
            <br/><br/>
            

            <input type="submit" class="submit" value="Formulario Incidente">

        </div>
    </form>
    <br/><br/><br/><br/><br/><br/>
    <form action="../vista/form_victimas.html" method="post">
        
        <label for="buscador">Formularios Victimas: </label> <br/><br/>
        <input type="submit" class="submit" value="Formulario Víctima">

    </form>


   
</body>
</html>